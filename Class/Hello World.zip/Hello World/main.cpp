/* 
 * File:   main.cpp
 * Author: Kami Alvey
 * Created on January 4, 2016, 10:17 AM
 * Purpose: Check out IDE
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare and initialize variables
    
    //Input Data
    
    //Calculate or Map Inputs
    
    //Output Results
    cout<<"Hello World"<<endl;
    
    //Exit Stage Right
    return 0;
}

